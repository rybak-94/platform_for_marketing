<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\OfferSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Offers';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="offer-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Offer', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        //'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'offer_name',
            'advertiser_id',
            't1_name',
            't1_value',
            // 't2_name',
            // 't2_value',
            // 't3_name',
            // 't3_value',
            // 't4_name',
            // 't4_value',
            // 't5_name',
            // 't5_value',
            // 't6_name',
            // 't6_value',
            // 't7_name',
            // 't7_value',
            // 't8_name',
            // 't8_value',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
