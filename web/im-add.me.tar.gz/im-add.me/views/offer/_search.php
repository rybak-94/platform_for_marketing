<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\OfferSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="offer-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'offer_name') ?>

    <?= $form->field($model, 'advertiser_id') ?>

    <?= $form->field($model, 't1_name') ?>

    <?= $form->field($model, 't1_value') ?>

    <?php // echo $form->field($model, 't2_name') ?>

    <?php // echo $form->field($model, 't2_value') ?>

    <?php // echo $form->field($model, 't3_name') ?>

    <?php // echo $form->field($model, 't3_value') ?>

    <?php // echo $form->field($model, 't4_name') ?>

    <?php // echo $form->field($model, 't4_value') ?>

    <?php // echo $form->field($model, 't5_name') ?>

    <?php // echo $form->field($model, 't5_value') ?>

    <?php // echo $form->field($model, 't6_name') ?>

    <?php // echo $form->field($model, 't6_value') ?>

    <?php // echo $form->field($model, 't7_name') ?>

    <?php // echo $form->field($model, 't7_value') ?>

    <?php // echo $form->field($model, 't8_name') ?>

    <?php // echo $form->field($model, 't8_value') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
