<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Advertiser;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\Offer */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="offer-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'offer_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'advertiser_id')->dropDownList(ArrayHelper::map(
    Advertiser::find()->all(), 'id', 'advertiser_name')) ?>

    <?= $form->field($model, 't1_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't1_value')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't2_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't2_value')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't3_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't3_value')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't4_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't4_value')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't5_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't5_value')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't6_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't6_value')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't7_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't7_value')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't8_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 't8_value')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
