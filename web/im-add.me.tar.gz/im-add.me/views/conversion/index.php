<?php

use yii\helpers\Html;
use yii\widgets\LinkPager;
?>

<h1>Conversion</h1>
<ul>
	<?php foreach ($conversions as $conversion): ?>
		<li>
			<?= Html::encode("{$conversion->offer_id}")?>:
			<?= $conversion -> status ?>
		</li>
<?php endforeach; ?>
</ul>
