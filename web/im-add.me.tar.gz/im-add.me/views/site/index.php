<?php

defined('YII_ENV') or define('YII_ENV', 'dev');
/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">


</div>
