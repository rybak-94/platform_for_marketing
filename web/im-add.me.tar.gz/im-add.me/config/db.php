<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=tracker_db',
    'username' => 'maxprofit',
    'password' => 'UsW%{4p:4GZ.h-B?',
    'charset' => 'utf8',
];
