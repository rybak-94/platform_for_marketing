<?php

namespace app\controllers;

use yii\web\Controller;
use yii\data\Pagination;
use app\models\Conversion;

class ConversionController extends Controller
{
    public function actionIndex()
    {
        $query = Conversion::find();

        $conversions = $query->orderBy('offer_id')
        ->all();

        return $this->render('index', [
            'conversions' => $conversions,
            ]);
    }
}