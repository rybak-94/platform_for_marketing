<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "payout".
 *
 * @property integer $id
 * @property integer $offer_id
 * @property string $country_code
 * @property double $default_payout
 * @property double $private_payout
 *
 * @property Offer $offer
 */
class Payout extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'payout';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['offer_id', 'default_payout', 'private_payout'], 'required'],
            [['offer_id'], 'integer'],
            [['default_payout', 'private_payout'], 'number'],
            [['country_code'], 'string', 'max' => 11],
            [['offer_id'], 'exist', 'skipOnError' => true, 'targetClass' => Offer::className(), 'targetAttribute' => ['offer_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'offer_id' => 'Offer ID',
            'country_code' => 'Country Code',
            'default_payout' => 'Default Payout',
            'private_payout' => 'Private Payout',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOffer()
    {
        return $this->hasOne(Offer::className(), ['id' => 'offer_id']);
    }
}
