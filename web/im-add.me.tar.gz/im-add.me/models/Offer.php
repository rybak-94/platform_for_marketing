<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "offer".
 *
 * @property integer $id
 * @property string $offer_name
 * @property integer $advertiser_id
 * @property string $t1_name
 * @property string $t1_value
 * @property string $t2_name
 * @property string $t2_value
 * @property string $t3_name
 * @property string $t3_value
 * @property string $t4_name
 * @property string $t4_value
 * @property string $t5_name
 * @property string $t5_value
 * @property string $t6_name
 * @property string $t6_value
 * @property string $t7_name
 * @property string $t7_value
 * @property string $t8_name
 * @property string $t8_value
 *
 * @property Conversion[] $conversions
 * @property Advertiser $advertiser
 * @property Payout[] $payouts
 */
class Offer extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'offer';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['offer_name', 'advertiser_id'], 'required'],
            [['advertiser_id'], 'integer'],
            [['offer_name'], 'string', 'max' => 255],
            [['advertiser_id'], 'exist', 'skipOnError' => true, 'targetClass' => Advertiser::className(), 'targetAttribute' => ['advertiser_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'offer_name' => 'Offer Name',
            'advertiser_id' => 'Advertiser name',
            't1_name' => 'T1 Name',
            't1_value' => 'T1 Value',
            't2_name' => 'T2 Name',
            't2_value' => 'T2 Value',
            't3_name' => 'T3 Name',
            't3_value' => 'T3 Value',
            't4_name' => 'T4 Name',
            't4_value' => 'T4 Value',
            't5_name' => 'T5 Name',
            't5_value' => 'T5 Value',
            't6_name' => 'T6 Name',
            't6_value' => 'T6 Value',
            't7_name' => 'T7 Name',
            't7_value' => 'T7 Value',
            't8_name' => 'T8 Name',
            't8_value' => 'T8 Value',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getConversions()
    {
        return $this->hasMany(Conversion::className(), ['offer_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAdvertiser()
    {
        return $this->hasOne(Advertiser::className(), ['id' => 'advertiser_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPayouts()
    {
        return $this->hasMany(Payout::className(), ['offer_id' => 'id']);
    }
}
