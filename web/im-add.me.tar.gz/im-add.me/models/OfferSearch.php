<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Offer;

/**
 * OfferSearch represents the model behind the search form about `app\models\Offer`.
 */
class OfferSearch extends Offer
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'advertiser_id'], 'integer'],
            [['offer_name', 't1_name', 't1_value', 't2_name', 't2_value', 't3_name', 't3_value', 't4_name', 't4_value', 't5_name', 't5_value', 't6_name', 't6_value', 't7_name', 't7_value', 't8_name', 't8_value'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Offer::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'advertiser_id' => $this->advertiser_id,
        ]);

        $query->andFilterWhere(['like', 'offer_name', $this->offer_name])
            ->andFilterWhere(['like', 't1_name', $this->t1_name])
            ->andFilterWhere(['like', 't1_value', $this->t1_value])
            ->andFilterWhere(['like', 't2_name', $this->t2_name])
            ->andFilterWhere(['like', 't2_value', $this->t2_value])
            ->andFilterWhere(['like', 't3_name', $this->t3_name])
            ->andFilterWhere(['like', 't3_value', $this->t3_value])
            ->andFilterWhere(['like', 't4_name', $this->t4_name])
            ->andFilterWhere(['like', 't4_value', $this->t4_value])
            ->andFilterWhere(['like', 't5_name', $this->t5_name])
            ->andFilterWhere(['like', 't5_value', $this->t5_value])
            ->andFilterWhere(['like', 't6_name', $this->t6_name])
            ->andFilterWhere(['like', 't6_value', $this->t6_value])
            ->andFilterWhere(['like', 't7_name', $this->t7_name])
            ->andFilterWhere(['like', 't7_value', $this->t7_value])
            ->andFilterWhere(['like', 't8_name', $this->t8_name])
            ->andFilterWhere(['like', 't8_value', $this->t8_value]);

        return $dataProvider;
    }
}
